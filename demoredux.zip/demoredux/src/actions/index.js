 export const increment = () =>{
    return{
    type:'INCREMENT'
    }
}
export const decrement = () =>{
    return{
    type:'DECREMENT'
    }
}

export const double = (nr) =>{
    return{
    type:'DOUBLE',
    payload:nr
    }
}

export const halfthenumer =(nm)=>{
    return{
        type:'HALF',
        payload:nm
    }
}

export const greetings =()=>{
    return{
        type:'GREET',
        message:'I am doing Good',
        question:'How are you and when are you coming back to India'
    }
}