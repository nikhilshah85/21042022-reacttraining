import { Component } from "react";

class Home extends Component
{
    constructor(props)
    {
      super(props);
    }

    render(){
        return(<div className="homeDiv">

          <h2 style={{color:'red'}}> Welcome to inline style</h2>

                      <h1> Welcome to Home - { this.props.devloper} </h1>
                      <p> this is the home page and this is going to be the landing page</p>

                      <p>On the General tab, under Home page, enter the URL of the site you want to set as a homepage.You can add more than one URL. Or, to add the site you're currently viewing, select Use current.If you add more than one URL, put each URL on its own line. </p>
                    
                    <p>The homepage or home page is the name of the main page of a website where visitors can find hyperlinks to other pages on the site. By default, the homepage on all web servers is index.html; however, it can also be index.htm, index.php, or whatever the developer decides.</p>


<p>
There is a page named "Home" on Wikipedia

Home
A home, or domicile, is a space used as a permanent or semi-permanent residence for one or many humans. It is a fully or semi sheltered space and can have
17 KB (3,843 words) - 21:47, 10 April 2022
Home (disambiguation)
lives there. Home may also refer to: Home, Kansas, U.S. Home, Pennsylvania, U.S. Home, Washington, U.S. Home, West Virginia, U.S. Home District, a former
19 KB (1,953 words) - 23:15, 20 March 2022
The History of Middle-earth (redirect from HoME)
The History of Middle-earth is a 12-volume series of books published between 1983 and 1996 that collect and analyse much of Tolkien's legendarium, compiled
6 KB (560 words) - 10:01, 20 February 2022
Home! Sweet Home!
"Home, Sweet Home" is a song adapted from American actor and dramatist John Howard Payne's 1823 opera Clari, or the Maid of Milan, the song's melody was
9 KB (959 words) - 00:12, 13 April 2022
Home Sweetie Home
Home Sweetie Home was a Philippine situational comedy broadcast by ABS-CBN, starring Toni Gonzaga and John Lloyd Cruz. The show premiered on January 5
16 KB (1,595 words) - 01:00, 21 April 2022
The Home & Home Tour
The Home & Home Tour was a tour by rappers Jay-Z and Eminem. The tour comprised two shows at Comerica Park in Detroit, Michigan, and two shows in Yankee
14 KB (932 words) - 19:22, 31 December 2021
At Home
At Home may refer to: At Home, a book of collected essays by Gore Vidal At Home, a recipe book by Heston Blumenthal At Home: A Short History of Private
1 KB (193 words) - 00:37, 20 September 2020
Home Sweet Home
Home Sweet Home may refer to: Home, Sweet Home (1914 film), a film about the life of John Howard Payne Home Sweet Home (1917 film), a British silent film
4 KB (468 words) - 03:39, 28 December 2021
Homer
Homer (/ˈhoʊmər/; Ancient Greek: Ὅμηρος [hómɛːros], Hómēros) was an ancient Greek author and epic poet. He is the reputed author of the Iliad and the
61 KB (6,652 words) - 14:57, 27 April 2022
List of Major League Baseball career home run leaders
hit the most home runs. In the sport of baseball, a home run is a hit in which the batter scores by circling all the bases and reaching home plate in one
16 KB (308 words) - 16:50, 28 April 2022
Home™
Home™ is the thirteenth studio album by American electronic musician Vektroid (under her alias PrismCorp Virtual Enterprises), released on April 20, 2013
8 KB (156 words) - 20:08, 30 March 2021
.home
.home is an ICANN rejected generic top-level domain proposed in 2012. The ICANN Board issued a resolution on February 4, 2018 to cease the processing of
2 KB (125 words) - 08:58, 21 December 2021
Home Alone
Home Alone is a 1990 American comedy film directed by Chris Columbus and written and produced by John Hughes. It is the first film in the Home Alone franchise
84 KB (7,866 words) - 20:03, 18 April 2022
Home, Tweet Home
Home, Tweet Home is a 1950 Warner Bros. Merrie Melodies animated short directed by Friz Freleng. The short was released on January 14, 1950, and stars
5 KB (610 words) - 00:21, 15 April 2022
Home Sweet Homer
Home Sweet Homer is a 1976 musical with a book by Roland Kibbee and Albert Marre, lyrics by Charles Burr and Forman Brown, and music by Mitch Leigh. Originally
6 KB (707 words) - 00:29, 24 October 2021
Home, Boys, Home
Home, Boys, Home is a compilation album by The Dubliners. "Mason's Apron" "The Nightengale" "The Holy Ground" "Home Boys Home" "Master McGrath" "Love
1 KB (68 words) - 18:07, 18 April 2022
This Is Home
"This is Home" is a song written and recorded by the alternative rock band Switchfoot, and is featured on the soundtrack for the 2008 film The Chronicles
12 KB (1,211 words) - 10:39, 25 September 2021
</p>
        </div>)

    }

      

}

export default Home;