import { Component } from "react";

class Login extends Component
{
    constructor(props)
    {
      super(props);
    }

    render(){
        return(<div className="loginDiv">
                      <h1> Welcome to Login - { this.props.devloper}  </h1>
                     
                     <input type="text" placeholder="Enter User Name"/> <br/>
                     <input type="password" placeholder="Enter your Password"/>
                     <button> Login </button>
                     <button> Reset </button>
        </div>)
    }

      

}

export default Login;