import { Component } from "react";

class About extends Component
{
    constructor(props)
    {
      super(props);
    }

    render(){
        return(<div className="aboutDiv">
                      <h1> Welcome to About - { this.props.devloper} </h1>
                      <h2> Something will be coming here about us soon</h2>

                <p>
                There is a page named "About" on Wikipedia </p>

About
About may refer to: About (surname) About.com, an online source for original information and advice about.me, a personal web hosting service abOUT, a Canadian
944 bytes (134 words) - 23:41, 10 February 2022
AbOUT
abOUT was a Toronto-based online biweekly lifestyles and current affairs magazine, serving the gay, lesbian, bisexual and transgender communities of North
2 KB (189 words) - 01:17, 22 January 2021
About us
About us may refer to: About Us (novel), 1967 a novel by Chester Aaron "About Us" (song), a 2007 song by Brooke Hogan About Us (album), a 2019 album by
529 bytes (88 words) - 14:48, 3 December 2020
All About Eve
All About Eve is a 1950 American drama film written and directed by Joseph L. Mankiewicz, and produced by Darryl F. Zanuck. It is based on the 1946 short
52 KB (5,420 words) - 21:40, 24 April 2022
About Schmidt
About Schmidt is a 2002 American comedy-drama film co-written and directed by Alexander Payne and starring Jack Nicholson in the title role. The film
15 KB (1,618 words) - 00:27, 4 March 2022
There's Something About Mary
There's Something About Mary is a 1998 American romantic comedy film directed by Peter Farrelly and Bobby Farrelly. It stars Cameron Diaz as the title
21 KB (2,201 words) - 14:54, 27 April 2022
We Don't Talk About Bruno
"We Don't Talk About Bruno" is a song from Disney's 2021 computer-animated musical feature film Encanto, with music and lyrics written by Lin-Manuel Miranda
49 KB (4,728 words) - 22:49, 20 April 2022
About Face
About Face may refer to: About-face, a drill command in which a unit or soldier makes a 180-degree turn About Face (1942 film), a 1942 American film About
2 KB (308 words) - 18:18, 26 March 2022
Mad About You
Mad About You is an American television sitcom starring Paul Reiser and Helen Hunt as a married couple in New York City. It initially aired on NBC from
35 KB (4,033 words) - 21:04, 20 April 2022
About Time
About Time may refer to: About Time (1962 film), a film in the Bell Laboratory Science Series About Time (2013 film), a British romantic time travel film
2 KB (209 words) - 04:25, 29 March 2021
10 Things I Hate About You
10 Things I Hate About You is a 1999 American romantic comedy film directed by Gil Junger and starring Julia Stiles, Heath Ledger, Joseph Gordon-Levitt
27 KB (2,630 words) - 06:27, 23 April 2022
About That
About That (Про это) is a poem by Vladimir Mayakovsky written during the self-imposed two-months "exile" after a row with Lilya Brik. It was finished
8 KB (1,001 words) - 23:22, 12 March 2022
About Time (2013 film)
About Time is a 2013 British science fantasy comedy-drama film written and directed by Richard Curtis, and starring Domhnall Gleeson, Rachel McAdams,
22 KB (2,257 words) - 13:58, 27 April 2022
Forget about it
Forget about it (catchphrase) associated with the American mafia Forget About It, eighth studio album by Alison Krauss Forget About It (film), 2006 film
401 bytes (81 words) - 15:12, 24 August 2020
What About Us
About Us may refer to: What About Us (Livin Out Loud album), or the title song What About Us? (Ruth-Ann Boyle album), or the title song "What About Us
1 KB (155 words) - 16:49, 24 November 2021
What About Bob?
What About Bob? is a 1991 American comedy film directed by Frank Oz and starring Bill Murray and Richard Dreyfuss. Murray plays Bob Wiley, a troubled
26 KB (2,906 words) - 17:06, 28 April 2022
About That Life
About That Life is the fifth studio album by American nu metalcore band Attila. The album was originally released on June 25, 2013, through Artery Recordings
8 KB (582 words) - 08:53, 8 November 2021
Man About the House
Man About the House is a British sitcom created by Brian Cooke and Johnnie Mortimer that starred Richard O'Sullivan, Paula Wilcox, Sally Thomsett, Yootha
13 KB (1,385 words) - 22:21, 20 February 2022
All About Steve
All About Steve is a 2009 American comedy film directed by Phil Traill and starring Sandra Bullock, Thomas Haden Church, and Bradley Cooper as the eponymous
12 KB (1,158 words) - 03:45, 20 February 2022
Fugget About It
Fugget About It was a Canadian adult animated sitcom created by Nicholas Tabarrok and Willem Wennekers for Teletoon's late night block, Teletoon at Night
22 KB (1,142 words) - 21:41, 28 April 2022
                
        </div>)
    }

      

}

export default About;