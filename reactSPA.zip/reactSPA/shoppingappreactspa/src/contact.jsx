import { Component } from "react";

class Contact extends Component
{
    constructor(props)
    {
      super(props);
    }


    render(){
        return(<div className="contactDiv">
                      <h1> Welcome to Contact Us - { this.props.devloper} </h1>
                    <h4 className={this.h4Look}> EMails : someone@somewhere.com</h4>
                    <h4> Call Us : 9856565464</h4>
                    <h4> Customer Care :  customers@somwhere.com</h4>
        </div>)
    }

      

}

export default Contact;