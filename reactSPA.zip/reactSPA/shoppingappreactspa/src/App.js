import logo from './logo.svg';
import './App.css';
import Home from './home';
import About from './about';
import Contact from './contact';
import Login from './login';
import { Route, Routes } from 'react-router-dom';
import Navigation from './Navigation';
import { Component } from 'react';

class App extends Component{

  constructor(props)
  {
    super(props);
  }

  developerName = 'Nikhil Shah';

  render(){
  return (
    <div>

      <h1 className="appLogo">  Welcome to Shopping APP </h1>
      <span className='appDeveloper'> {this.developerName}</span>
      <Navigation></Navigation>


      {/* <Home></Home>
      <About></About>
      <Contact></Contact>
      <Login></Login> */}
      <Routes>
        <Route path='home' element={<Home devloper={this.developerName}/>}/>
        <Route path='about' element={<About devloper={this.developerName}/>}/>
        <Route path='contact' element={<Contact devloper={this.developerName}/>}/>
        <Route path='login' element={<Login devloper={this.developerName}/>}/>
      </Routes>
    </div>
  );}
}

export default App;
